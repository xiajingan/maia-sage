# maia-mud-client 0.5.0

由 Mud 实际 Fastify OpenAPI 3.0.3 与 `@hey-api/openapi-ts@0.99.0` 生成的 ESM Fetch 客户端。契约与 Schema 只由 Mud 维护；不包含后端 Seed 或任何秘密。

根导出 `getSession`、`listMembers`、`logout`、`createClient`、`createConfig`，以及生成的 `Options`、`GetSessionResponse`、`ListMembersResponse`、`LogoutResponse` 等类型；`./schemas` 导出 `SessionViewSchema`、`MembersViewSchema`、`ErrorViewSchema`、`LogoutInputSchema`、`LogoutViewSchema`，均直接来自 Mud TypeBox Schema，可用 Ajv 编译运行时校验。

```ts
import { createClient, getSession, listMembers, logout } from "maia-mud-client";
const client = createClient({ baseUrl: window.location.origin });
const current = await getSession({ client, auth: accessToken });
const members = await listMembers({
  client,
  auth: accessToken,
  path: { workspaceId },
  query: { limit: 20 },
});
const result = await logout({
  client,
  credentials: "same-origin",
  body: { idTokenHint, logoutRequestId },
});
```

`baseUrl` 是源，例如 `https://localhost:15443`，**不包含** `/api/mud`。生成方法已经包含 `/api/mud/v1/session`、`/api/mud/v1/workspaces/{workspaceId}/members`、`/api/mud/auth/logout`。浏览器退出请求自动携带 Origin 和同源 HttpOnly cookie；Node 协议测试才显式设 Origin。

实际函数签名：

```ts
getSession<ThrowOnError extends boolean = false>(
  options?: Options<GetSessionData, ThrowOnError>
): RequestResult<GetSessionResponses, GetSessionErrors, ThrowOnError>;
listMembers<ThrowOnError extends boolean = false>(
  options: Options<ListMembersData, ThrowOnError>
): RequestResult<ListMembersResponses, ListMembersErrors, ThrowOnError>;
logout<ThrowOnError extends boolean = false>(
  options: Options<LogoutData, ThrowOnError>
): RequestResult<LogoutResponses, LogoutErrors, ThrowOnError>;
```

默认返回 Promise 的 `{ data?, error?, request?, response? }`，网络错误可能没有 response。401 重新登录，403 当前权限无效，404 根不可访问，503 服务不可读／结果待核实。返回 JSON 必须用对应运行时 Schema 验证，不能仅相信 TS 类型。退出结果未知时保留内存中的原 hint/requestId，可在 600 秒恢复窗口内重试；不能显示服务端已经退出。随机 `logoutRequestId` 为 22–128 位 base64url，换账号／离页后丢弃原退出操作；旧查询响应须通过会话代次校验后再显示。

## 个人终端

- `issueTerminalActivation({ client, auth: accessToken, body: {} })` 签发一次性码，返回 `{code, expiresAt}`。
- `listTerminals({ client, auth: accessToken, query: { limit: 20 } })` 读取个人终端。传回非空的 `nextCursor` 续页。
- `getTerminal({ client, auth: accessToken, path: { terminalId } })` 读取根内终端详情。
- `./schemas` 对应导出 `ActivationViewSchema`、`TerminalPageSchema`、`TerminalViewSchema` 和 `TerminalErrorViewSchema`。终端错误包含 `code` 和 `requestId`。

## OIDC 配套要求

issuer=`https://localhost:15443/api/mud/auth`，client_id=`sage`，精确 redirect_uri=`https://localhost:15443/auth/callback`，发现 URL 为 `${issuer}/.well-known/openid-configuration`。使用授权码 + S256 PKCE，scope=`openid`，新的随机 state/nonce，并传：

```ts
const oidcSettings = {
  extraQueryParams: {
    claims: JSON.stringify({ id_token: { sid: { essential: true } } }),
  },
};
```

上述为 oidc-client-ts 的 `extraQueryParams` 写法，线上查询参数 `claims` 的值是 JSON 字符串（见[官方设置接口](https://authts.github.io/oidc-client-ts/interfaces/OidcClientSettings.html#extraqueryparams)）。缺少 sid claim 的授权不会发出 code。初次或主动重新输入账号传 `prompt:'login'`；刷新后顶层恢复可不传 prompt，服务端自行判定当前会话。明确密码登录成功后，该浏览器原 session/grant 失效，新主体获得新 session。access token、ID token 仅内存，不能写 localStorage/sessionStorage；短期 PKCE verifier/state/nonce 可放当前标签页 sessionStorage。

Sage 的 `oidc-client-ts` 配置必须设置 `loadUserInfo:false`；本 issuer 禁用 userinfo，业务资料由 `getSession` 提供。

ID token 为 RS256，sub 是根内 User，sid 是原会话退出关联。必须通过 issuer JWKS 验证 JWS，再验证 iss/aud/exp/nonce/state/sid；`oidc-client-ts` 的 claims 解码本身不验 JWS。业务 API 仅接受 access token，ID token 只用于原会话退出证明。

服务端不启用 refresh/implicit/device/动态注册。退出端点永不发送 Set-Cookie，ID token 已过期时，活动原会话的签名 HttpOnly cookie 可提供同一 sid/sub/grant 的证明；旧退出请求／响应不改变新会话。

## 构建与本地制品

总仓 `pnpm client:generate` 从 `artifacts/openapi.json` 实际生成 SDK、从 Mud Schema 导出 JSON Schema，然后独立 strict TS 编译；服务端额外开启 exactOptionalPropertyTypes，生成器本身暂不兼容此附加开关，消费者使用包内 `.d.ts/.js`。`pnpm client:pack` 仅允许首次写入该版本 tarball；变更已发布制品时必须提升版本，不能覆盖既有文件。本地制品不代表生产 registry 发布、签名或 E2E 验收。

## 企微安装

0.3.0向后兼容增加`createWecomInstallOperation`、`getWecomInstallOperation`、`completeWecomInstallOperation`和`listChannelAppInstances`；均使用原Maia内存Bearer。`./schemas`新增`InstallViewSchema`、`InstallInputSchema`、`InstallCompleteSchema`和`ChannelInstancesViewSchema`，不手写平行DTO。

创建body为`{clientRequestId,mode:'member'|'admin'}`，path为`{workspaceId}`；查询path为`{id}`，完成body为`{rowVersion}`；列表path为`{workspaceId}`，可选query.cursor。客户端不提交sid/企业/管理员事实。返回phase与safeReason才是业务结果，扫码/回调接收成功不等于实例完成；返回页只通知回到原页面，原窗口用自身Bearer查原操作。

未知交换保留原operationId重复查询；明确重新发起使用新clientRequestId，不能自动重发旧code。409重查所见版本，410显示过期新发起。实例scope是本Workspace证据摘要（成员仅本人、管理员明确授权），不是平台企业全员名单；sync、archive与terminal分别呈现。联系人 API 已由 0.4.0 发布；姓名 API 由 0.5.0 发布，见下节。

## 联系人及姓名上下文（0.4.0 / 0.5.0）

0.4.0 发布 `listContacts`、`requestContactSync`、`getContactSync`。0.5.0 增加 `createNameContext`、`getNameContext`、`completeNameContext`、`getNameComponentConfig` 与对应 TypeBox Schema；新制品不替换旧版本。

四个姓名接口均使用原内存 Bearer、同源 Fetch Cookie 和 path.id（实例 ID）；query/complete 的 path.operationId 为原操作。create body 为 `{clientRequestId,pageKey:'instance_contacts',environment:'member'|'web'}`；complete body 为 `{rowVersion}`；config body 为 `{operationId,pageKey:'instance_contacts',limit?,cursor?}`。limit 1～100 默认50，cursor 与联系人分页相同。服务器固定页面为 `/workspaces/:workspaceId/channel-app-instances/:instanceId/contacts`（无query/hash），config.pageUrl 必须与页面当前实际 URL 一致。

回调 303 到 `/wecom/name-context-result?operationId=...`；结果页同源通知只传 operationId，原窗口检查 origin/source 后用自身 Bearer 查询并完成。企微内整页返回须 PKCE/prompt=none 恢复原 sid；不持久化 Bearer。服务端生成 HttpOnly Cookie，前端不读写或提交 sid/browserDigest。缺独立登录配置返回 `nextAction=check_configuration`；不循环授权，不通过业务 Suite 冒充 Web 登录。

config 返回公开的 corpId/agentId/nonceStr/timestamp/corpSignature/agentSignature、expiresAt/scopeVersion、references 和 nextCursor；references 中 userId 仅用于官方 userName 组件，不是可执行账号或真实姓名。退出/切根/范围变化/失权立即清除组件和旧异步响应。签名或 SDK 初始化成功不表示实际姓名正确；真实参与者确认前保持未验收。
