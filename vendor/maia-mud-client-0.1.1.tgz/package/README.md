# maia-mud-client 0.1.1

由 Mud 实际 Fastify OpenAPI 3.0.3 与 `@hey-api/openapi-ts@0.99.0` 生成的 ESM Fetch 客户端。契约与 Schema 只由 Mud 维护；不包含后端 Seed 或任何秘密。

根导出 `getSession`、`listMembers`、`logout`、`createClient`、`createConfig`，以及生成的 `Options`、`GetSessionResponse`、`ListMembersResponse`、`LogoutResponse` 等类型；`./schemas` 导出 `SessionViewSchema`、`MembersViewSchema`、`ErrorViewSchema`、`LogoutInputSchema`、`LogoutViewSchema`，均直接来自 Mud TypeBox Schema，可用 Ajv 编译运行时校验。

```ts
import { createClient, getSession, listMembers, logout } from "maia-mud-client";
const client = createClient({ baseUrl: window.location.origin });
const current = await getSession({ client, auth: accessToken });
const members = await listMembers({
  client,
  auth: accessToken,
  path: { workspaceId },
  query: { limit: 20 },
});
const result = await logout({
  client,
  credentials: "same-origin",
  body: { idTokenHint, logoutRequestId },
});
```

`baseUrl` 是源，例如 `https://localhost:15443`，**不包含** `/api/mud`。生成方法已经包含 `/api/mud/v1/session`、`/api/mud/v1/workspaces/{workspaceId}/members`、`/api/mud/auth/logout`。浏览器退出请求自动携带 Origin 和同源 HttpOnly cookie；Node 协议测试才显式设 Origin。

实际函数签名：

```ts
getSession<ThrowOnError extends boolean = false>(
  options?: Options<GetSessionData, ThrowOnError>
): RequestResult<GetSessionResponses, GetSessionErrors, ThrowOnError>;
listMembers<ThrowOnError extends boolean = false>(
  options: Options<ListMembersData, ThrowOnError>
): RequestResult<ListMembersResponses, ListMembersErrors, ThrowOnError>;
logout<ThrowOnError extends boolean = false>(
  options: Options<LogoutData, ThrowOnError>
): RequestResult<LogoutResponses, LogoutErrors, ThrowOnError>;
```

默认返回 Promise 的 `{ data?, error?, request?, response? }`，网络错误可能没有 response。401 重新登录，403 当前权限无效，404 根不可访问，503 服务不可读／结果待核实。返回 JSON 必须用对应运行时 Schema 验证，不能仅相信 TS 类型。退出结果未知时保留内存中的原 hint/requestId，可在 600 秒恢复窗口内重试；不能显示服务端已经退出。随机 `logoutRequestId` 为 22–128 位 base64url，换账号／离页后丢弃原退出操作；旧查询响应须通过会话代次校验后再显示。

## OIDC 配套要求

issuer=`https://localhost:15443/api/mud/auth`，client_id=`sage`，精确 redirect_uri=`https://localhost:15443/auth/callback`，发现 URL 为 `${issuer}/.well-known/openid-configuration`。使用授权码 + S256 PKCE，scope=`openid`，新的随机 state/nonce，并传：

```ts
const oidcSettings = {
  extraQueryParams: {
    claims: JSON.stringify({ id_token: { sid: { essential: true } } }),
  },
};
```

上述为 oidc-client-ts 的 `extraQueryParams` 写法，线上查询参数 `claims` 的值是 JSON 字符串（见[官方设置接口](https://authts.github.io/oidc-client-ts/interfaces/OidcClientSettings.html#extraqueryparams)）。缺少 sid claim 的授权不会发出 code。初次或主动重新输入账号传 `prompt:'login'`；刷新后顶层恢复可不传 prompt，服务端自行判定当前会话。明确密码登录成功后，该浏览器原 session/grant 失效，新主体获得新 session。access token、ID token 仅内存，不能写 localStorage/sessionStorage；短期 PKCE verifier/state/nonce 可放当前标签页 sessionStorage。

Sage 的 `oidc-client-ts` 配置必须设置 `loadUserInfo:false`；本 issuer 禁用 userinfo，业务资料由 `getSession` 提供。

ID token 为 RS256，sub 是根内 User，sid 是原会话退出关联。必须通过 issuer JWKS 验证 JWS，再验证 iss/aud/exp/nonce/state/sid；`oidc-client-ts` 的 claims 解码本身不验 JWS。业务 API 仅接受 access token，ID token 只用于原会话退出证明。

服务端不启用 refresh/implicit/device/动态注册。退出端点永不发送 Set-Cookie，ID token 已过期时，活动原会话的签名 HttpOnly cookie 可提供同一 sid/sub/grant 的证明；旧退出请求／响应不改变新会话。

## 构建与本地制品

总仓 `pnpm client:generate` 从 `artifacts/openapi.json` 实际生成 SDK、从 Mud Schema 导出 JSON Schema，然后独立 strict TS 编译；服务端额外开启 exactOptionalPropertyTypes，生成器本身暂不兼容此附加开关，消费者使用包内 `.d.ts/.js`。`pnpm client:pack` 仅允许首次写入该版本 tarball；变更已发布制品时必须提升版本，不能覆盖既有文件。本地制品不代表生产 registry 发布、签名或 E2E 验收。
